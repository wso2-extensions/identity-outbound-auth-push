package org.wso2.carbon.identity.sso.saml.servlet;
//import com.sun.xml.internal.ws.util.StringUtils;
//import sun.swing.StringUIClientPropertyKey;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.*;
import java.io.Console;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

public class SAMLBiometricServlet extends HttpServlet {

    boolean value1 = false;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);


    }
    HashMap<String, String> updateStatus = new HashMap<>();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (request.getParameterMap().containsKey("t")) {
            String para1 = request.getParameter("t");
            System.out.println("t parameter is : " + para1);

            //HashMap<String, String> updateStatus = new HashMap<>();

            if (para1.equals("mobile")) {


                if ((request.getParameterMap().containsKey("SDKMobile"))&& request.getParameterMap().containsKey("CHALLENGEMobile")) {
                    String sdkmobile = request.getParameter("SDKMobile");
                    String challengeMobile= request.getParameter("CHALLENGEMobile");
                    System.out.println("challenge mobile parameter is : " + challengeMobile);
                    System.out.println("sdk mobile parameter is : " + sdkmobile);
                    updateStatus.put(sdkmobile, "SUCCESS");
                    System.out.println("table is: "+ updateStatus);
                    response.setContentType("text/html");
                    response.setStatus(200);
                    PrintWriter out = response.getWriter();
                    System.out.println("<h3>Parameter 't' is here!</h3>");
                    return;
                }
            }
            else if (para1.equals("web")) {

                if (request.getParameterMap().containsKey("SDKWeb")) {
                    String sdkweb = request.getParameter("SDKWeb");
                    System.out.println("sdk web parameter is : " + sdkweb);
                    String status=updateStatus.get(sdkweb);
                    System.out.println("SDK web status of the hashmap iss:  "+status);
                    //assert status != null;
                    if (status!=null && status.equals("SUCCESS")){
                        response.setStatus(200);
                        System.out.println("a response has arrived from the mobile device!!!");
                        //response.sendRedirect("https://localhost:9443/authenticationendpoint/success.do");

                    } else {
                        response.setContentType("text/html");
                        //response.setStatus(401);
                        //response.sendError(401, "blah blah ");
                        response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "message goes here");
//                        PrintWriter out = response.getWriter();
//                        out.println("<h3>Please wait until the authorization process is over... !</h3>");
                        System.out.println("<Please wait until the authorization process is over... !</h3>");

                    }
                }
            }
        }

        else {
            response.setContentType("text/html");
            response.setStatus(400);
            PrintWriter out = response.getWriter();
            out.println("<h3>Invalid request... !</h3>");
            System.out.println("<Please wait until the authorization process is over... !</h3>");
        }
    }
}
