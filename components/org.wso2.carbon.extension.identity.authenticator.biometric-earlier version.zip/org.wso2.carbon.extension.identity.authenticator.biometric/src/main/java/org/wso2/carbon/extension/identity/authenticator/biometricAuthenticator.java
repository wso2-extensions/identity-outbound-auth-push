/*
 *  Copyright (c) 2015, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
 *
 *  WSO2 Inc. licenses this file to you under the Apache License,
 *  Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 *
 */

package org.wso2.carbon.extension.identity.authenticator;

import org.apache.oltu.oauth2.client.response.OAuthClientResponse;
import org.wso2.carbon.core.services.authentication.AbstractAuthenticator;
import org.wso2.carbon.identity.application.authentication.framework.AbstractApplicationAuthenticator;
import org.wso2.carbon.identity.application.authentication.framework.context.AuthenticationContext;
import org.wso2.carbon.identity.application.authentication.framework.exception.AuthenticationFailedException;
import org.wso2.carbon.identity.application.authentication.framework.model.AuthenticatedUser;
import org.wso2.carbon.identity.application.authenticator.oidc.OIDCAuthenticatorConstants;
import org.wso2.carbon.identity.application.authenticator.oidc.OpenIDConnectAuthenticator;
import org.wso2.carbon.identity.application.authentication.framework.FederatedApplicationAuthenticator;
import org.wso2.carbon.identity.application.common.model.Property;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.*;

/**
 * Authenticator of biometric
 */
public class biometricAuthenticator extends AbstractApplicationAuthenticator
        implements FederatedApplicationAuthenticator {

    private static Log log = LogFactory.getLog(biometricAuthenticator.class);

    /**
     * Get the friendly name of the Authenticator
     */
    @Override
    public String getFriendlyName() {
        return biometricAuthenticatorConstants.AUTHENTICATOR_FRIENDLY_NAME;
    }

    @Override
    public boolean canHandle(HttpServletRequest httpServletRequest) {
        return false;
    }

    @Override
    public String getContextIdentifier(HttpServletRequest httpServletRequest) {
        return null;
    }

    /**
     * Get the name of the Authenticator
     */
    @Override
    public String getName() {
        return biometricAuthenticatorConstants.AUTHENTICATOR_NAME;
    }

    protected String getTokenEndpoint(Map<String, String> authenticatorProperties) {
        return authenticatorProperties.get(biometricAuthenticatorConstants.SERVER_KEY);
    }



    @Override
    protected void initiateAuthenticationRequest(HttpServletRequest request, HttpServletResponse response, AuthenticationContext context) throws AuthenticationFailedException {
        AuthenticatedUser user = context.getSequenceConfig().getStepMap().get(1).getAuthenticatedUser();

        String DBusername = user.getUserName();


        Map<String, String> authenticatorProperties = context.getAuthenticatorProperties();
        String FirebaseSK = authenticatorProperties.get(biometricAuthenticatorConstants.SERVER_KEY);
        String tokenEndPoint = getTokenEndpoint(authenticatorProperties);




        List<String> putIds;


        //String server_key ="AAAAJp0GZ-I:APA91bHfqf4eWjGbQSIPE6o_gEduOTPhEeOEdoVu5sEN106kbI30-YY8J9ySsh0Vj3QDCd7ovqjVlhyMuEkuLapQNYe6Ta7of0aT4FFAOLqZ3E_FrbSZWhn5kyypaRV-bFHS34Falvnn" ;
        String message = "Authenticate with your fingerprint44";
        String server_key = FirebaseSK;


        UUID uuid = UUID.randomUUID();
        String randomUUIDString = uuid.toString();
        System.out.println("Random UUID String = " + randomUUIDString);

        HashMap<String, String> tokenList = new HashMap<>();

        tokenList.put("dewni", "ca0OWsg-30c:APA91bHQj3LRdOt7BgQJsOGbz_uWBFe8BtBLS0WSXZFNnVj6BZkU7PM__bHuoZXE6z_mzsjdZaKMerHaILfsf2jalgpndp67b5Vt9xvG0lODmksCq-Nk5N8pdIv1DRHJkVZGKygFcnmw");
        tokenList.put("chamodi", "cMXgOC6PIFA:APA91bHbV-ZT6JJnqPtt_0jCtImNFtEFefhY3FAck83eZkUBnRmUevrgLbo3G1iC8Xf8dpH3mQ0kVhnJTHnoX_8UocAc5Y1-zbEbTUYQMdFNFruT77KX8skRRF7XY_X8C4Wlo3nZmWAu");
        String tokenId = tokenList.get(DBusername);


        putIds = new ArrayList();
        //putIds.add(tokenId1);
        putIds.add(tokenId);


        /*for individual*/
        PushNotif.send_FCM_Notification(tokenId, server_key, message, randomUUIDString);


    }




    @Override
    protected void processAuthenticationResponse(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, AuthenticationContext authenticationContext) throws AuthenticationFailedException {

    }

    /**
     * Get Configuration Properties
     */
    @Override
    public List<Property> getConfigurationProperties() {
        //Add your configuration properties

        List<Property> configProperties = new ArrayList<Property>();
//        Property username = new Property();
//        username.setName(biometricAuthenticatorConstants.USERNAME);
//        username.setDisplayName("Enter the Username");
//        username.setDescription("Enter the username that is registered in WSO2 IS");
//        username.setDisplayOrder(0);
//        configProperties.add(username);

        Property serverKey = new Property();
        serverKey.setName(biometricAuthenticatorConstants.SERVER_KEY);
        serverKey.setDisplayName("Firebase Server Key");
        serverKey.setDescription("Enter the firebase server key of the android app");
        serverKey.setDisplayOrder(1);
        configProperties.add(serverKey);


        return configProperties;
    }
}